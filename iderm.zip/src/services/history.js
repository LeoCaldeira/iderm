import { createBrowserHistory } from 'history';

export default createBrowserHistory();